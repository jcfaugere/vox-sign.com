/******************************************************************************
 * Tools for FGLM algorithm
 ******************************************************************************
 * Copyright (C) 2023  The VOX team
 * License : MIT (see COPYING file for the full text)
 * Author  : Jean-Charles Faugère
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "vox_params.h"
#include "Fq_arith.h"

#if (VOX_Q_BITS <= 8)
typedef uint8_t GFq;
typedef uint16_t GFq_2;
#elif (VOX_Q_BITS <= 16)
typedef uint16_t GFq;
typedef uint32_t GFq_2;
#else
#error "Unsupported parameters"
#endif

typedef uint32_t GFq_4;

static inline uint32_t NORMAL(uint32_t x) {
  return Fq_reduce(x);
}


static inline GFq_2 mul_GFq_2(GFq_2 a,GFq_2 b) {
  const uint32_t c = ((uint32_t) a) * ((uint32_t) b);
  return Fq_reduce(c);
}
static inline GFq mul_GFq(GFq a,GFq b) {
  const uint32_t c = ((uint32_t) a) * ((uint32_t) b);
  return Fq_reduce(c);
}
static inline GFq_2 add_GFq_2(GFq_2 a,GFq_2 b)
{
  const GFq_4 _tmp=a+b;
  if (_tmp>=VOX_Q)
    return (GFq_2)(_tmp-VOX_Q);
  else
    return _tmp;
}
static inline GFq_2 neg_GFq_2(GFq_2 a) { if (a) return VOX_Q-a; return 0;}

static inline void lin_GFq_2(GFq_2 *acc, int32_t i, GFq_2 a, GFq_2 b) {
  uint32_t tmp = acc[i] + ((uint32_t) a) * ((uint32_t) b);
  acc[i] = Fq_reduce(tmp);
}

#include "tables/invmod_table.h"
GFq_2 inv_GFq_2(GFq_2 q)
{
  return invmod_table[q];
}


static GFq main_comp_internal(GFq* a,GFq* b,const uint32_t n)
{
  uint32_t A=0;
  for(uint32_t j=0;j<n;j++)
    A = Fq_addmul(A, a[j], b[j]);
  return Fq_reduce(A);
}

