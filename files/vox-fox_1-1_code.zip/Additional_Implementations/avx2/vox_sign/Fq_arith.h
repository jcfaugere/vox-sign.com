/******************************************************************************
 * Arithmetic over Fq
 ******************************************************************************
 * Copyright (C) 2024  The VOX team
 * License : MIT (see COPYING file for the full text)
 * Author  : Robin Larrieu
 *****************************************************************************/
#ifndef VOX_FQ_ARITH_H
#define VOX_FQ_ARITH_H


#include <stdint.h>
#include <immintrin.h>
#include "vox_params.h"

/*
 * Assertions may be enabled for debugging using the macro below, and to
 * document the input/output assumptions of each function to help the reader.
 */
#if 0
#include <assert.h>
#define VOX_ENABLE_ASSERTIONS 1
#define VOX_ASSERT  assert
#else
#define VOX_ENABLE_ASSERTIONS 0
#define VOX_ASSERT(x)
#endif

/*
 * The constant Q^2 that may be useful in some situations
 */
#if (VOX_C > 1) || VOX_ENABLE_ASSERTIONS
static const uint32_t VOX_Q2 = VOX_Q * ((uint32_t) VOX_Q);
#endif


/*
 * Additions
 */
#if VOX_Q <= 4093
#define Fq_sum_t  uint16_t
#define Fq_msb(x) ((x) >> 15)
#else
#define Fq_sum_t  uint32_t
#define Fq_msb(x) ((x) >> 31)
#endif


static inline Fq Fq_add(Fq a, Fq b) {
  VOX_ASSERT(a <= VOX_Q);
  VOX_ASSERT(b <= VOX_Q);
  /* Force lift in uint16_t as the addition would overflow if Q=251 and Fq = uint8_t */
  Fq_sum_t tmp = (Fq_sum_t) (a + ((Fq_sum_t) b) - VOX_Q);
  Fq_sum_t mask = - Fq_msb(tmp);
  return (Fq) (tmp + (VOX_Q & mask));
}

static inline Fq Fq_neg(Fq a) {
  Fq_sum_t tmp = (Fq_sum_t) (- ((Fq_sum_t) a));
  Fq_sum_t mask = - Fq_msb(tmp); /* 0 if a == 0, 0xFFFF otherwise */
  return (Fq) (tmp + (VOX_Q & mask));
}


/*
 * Barrett reduction of any 32-bit integer modulo Q
 */
static Fq Fq_reduce(uint32_t x) {
  /* Barrett inverse 2^32 / Q */
#if   (VOX_Q == 251)
#define VOX_QINV  UINT32_C(17111423)
#elif (VOX_Q == 1021)
#define VOX_QINV  UINT32_C(4206628)
#elif (VOX_Q == 4093)
#define VOX_QINV  UINT32_C(1049344)
#elif (VOX_Q == 65521)
#define VOX_QINV  UINT32_C(65551)
#else
#error "Unsupported parameters"
#endif
  /* Compiler should be able to optimize this as a high multiplication
   * on 32-bit platforms */
  uint32_t m = (uint32_t) (((uint64_t) x * (uint64_t) VOX_QINV) >> 32);
  m = x - VOX_Q * m;
  /* Result is currently in [0, 2*Q) -> perform conditional subtraction */
  m -= VOX_Q;
  uint32_t mask = - (m >> 31);
  m += VOX_Q & mask;
  VOX_ASSERT(x % VOX_Q == m);
  return (Fq) m;
}

static inline __m256i FqX8_reduce(__m256i x) {
  __m256i qinv = _mm256_set1_epi64x(VOX_QINV);
  __m256i q  = _mm256_set1_epi32(VOX_Q);
  __m256i x2 = _mm256_srli_epi64(x, 32);
  __m256i m1 = _mm256_mul_epu32(x, qinv);
  __m256i m2 = _mm256_mul_epu32(x2, qinv);
  m1 = _mm256_blend_epi32(_mm256_srli_epi64(m1, 32), m2, 0xAA);
  m1 = _mm256_sub_epi32(x, _mm256_mullo_epi32(m1, q));
  m1 = _mm256_sub_epi32(m1, q);
  m2 = _mm256_and_si256(q, _mm256_srai_epi32(m1, 31));
  return _mm256_add_epi32(m1, m2);
}


/*
 * Lazy multiply-accumulate  u + a*b
 * This function is used in the linear algebra subroutines, and in the FGLM
 * algorithm for the change of monomial ordering. In the first use case, it is
 * called at most N times successively (with an initial value in standard
 * representation [0,Q]). In the second use case, it is called at most
 * 2^T <= 256 times successively (with an initial value of 0 for the
 * accumulator).
 *
 * Except for Full-VOX-256 (Q=65521), we have Q + N*Q^2 < 2^32
 * and 256*Q^2 < 2^32, so there is no overflow in these cases.
 * For Full-VOX-256, we need to reduce each time to prevent overflow. To
 * speed things up, we perform a partial reduction, exploiting the
 * fact that Q = 2^16 - 16.
 */
static inline uint32_t Fq_addmul(uint32_t u, const Fq a, const Fq b) {
  VOX_ASSERT(a <= VOX_Q);
  VOX_ASSERT(b <= VOX_Q);
#if (VOX_Q == 65521 && VOX_C == 1)
  VOX_ASSERT(u < 1048576); /* 16*2^16 */
  /* u + a*b does not overflow since 16*2^16 + Q^2 < 2^32 */
  uint32_t acc = u + ((uint32_t) a) * ((uint32_t) b);
  uint32_t high = acc >> 16;
  uint32_t low  = acc & 0xFFFF;
  acc = low + 15*high; /* Q = 2^16 - 15 */
  /* This variant gives a result < 16*2^16 */
  VOX_ASSERT(acc < 1048576);
  return acc;
#else /* All but Full-VOX-256 */
  /* For all other parameter sets, we have Q + N*Q^2 < 256*Q^2 < 2^32 */
  VOX_ASSERT(u < 255*VOX_Q2);
  uint32_t acc = u + ((uint32_t) a) * ((uint32_t) b);
  /* Nothing special to do since 256*Q^2 < 2^32 */
  VOX_ASSERT(acc < 256*VOX_Q2);
  return acc;
#endif /* Special care for Full-VOX-256 */
}


#endif /* VOX_FQ_ARITH_H */
