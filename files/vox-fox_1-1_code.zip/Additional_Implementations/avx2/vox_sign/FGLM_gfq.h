/******************************************************************************
 * Tools for FGLM algorithm
 ******************************************************************************
 * Copyright (C) 2023  The VOX team
 * License : MIT (see COPYING file for the full text)
 * Author  : Jean-Charles Faugère
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "vox_params.h"
#include "Fq_arith.h"

#if (VOX_Q_BITS <= 8)
typedef uint8_t GFq;
typedef uint16_t GFq_2;
#define SIZE_GFQ 1
#elif (VOX_Q_BITS <= 16)
typedef uint16_t GFq;
typedef uint32_t GFq_2;
#define SIZE_GFQ 2
#else
#error "Unsupported parameters"
#endif

typedef uint32_t GFq_4;


static inline uint32_t NORMAL(uint32_t x) {
  return Fq_reduce(x);
}


static inline GFq_2 mul_GFq_2(GFq_2 a,GFq_2 b) {
  const uint32_t c = ((uint32_t) a) * ((uint32_t) b);
  return Fq_reduce(c);
}
static inline GFq mul_GFq(GFq a,GFq b) {
  const uint32_t c = ((uint32_t) a) * ((uint32_t) b);
  return Fq_reduce(c);
}
static inline GFq_2 add_GFq_2(GFq_2 a,GFq_2 b)
{
  const GFq_4 _tmp=a+b;
  if (_tmp>=VOX_Q)
    return (GFq_2)(_tmp-VOX_Q);
  else
    return _tmp;
}
static inline GFq_2 neg_GFq_2(GFq_2 a) { if (a) return VOX_Q-a; return 0;}

static inline void lin_GFq_2(GFq_2 *acc, int32_t i, GFq_2 a, GFq_2 b) {
  uint32_t tmp = acc[i] + ((uint32_t) a) * ((uint32_t) b);
  acc[i] = Fq_reduce(tmp);
}

#include "tables/invmod_table.h"
GFq_2 inv_GFq_2(GFq_2 q)
{
  return invmod_table[q];
}

#include <immintrin.h>
typedef __m256i const *m256_ptr;
/* pointer to a memory location that can hold constant integer values; the address must be 32-byte aligned */


#if VOX_Q_BITS == 16
/* Widening horizontal addition, assuming m = _mm256_set1_epi32(0xFFFF)
 * [x0,x1,...,x15] (16x16) -> [x0+x1, ..., x14+x15] (8x32) */
static inline __m256i _mm256_haddw_epi16(__m256i x, __m256i m) {
  __m256i u = _mm256_and_si256(x, m);
  __m256i v = _mm256_srli_epi32(x, 16);
  return _mm256_add_epi32(u, v);
}

static GFq main_comp_internal(GFq* a,GFq* b,const uint32_t n)
{
  __m256i A=_mm256_setzero_si256();
  __m256i m = _mm256_set1_epi32(0xFFFF);
  for(int32_t i=n-16;i>=0;i-=16)
    {
      __builtin_prefetch(a+i-16);
      __builtin_prefetch(b+i-16);

      __m256i x=_mm256_load_si256((m256_ptr)(a+i));  /* <a0,a1,a2,a3,...,a16> */
      __m256i y=_mm256_load_si256((m256_ptr)(b+i));  /* <b0,b1,b2,b3,...,b16> */
      __m256i high = _mm256_mulhi_epu16(x, y); /* < high 16 bits of ai*bi > */
      __m256i low  = _mm256_mullo_epi16(x, y); /* < low 16 bits of ai*bi > */
      high = _mm256_haddw_epi16(high, m);
      low  = _mm256_haddw_epi16(low, m);
      y = _mm256_sub_epi32(_mm256_slli_epi32(high, 4), high);
      A = _mm256_add_epi32(A, _mm256_add_epi32(low, y)); // A += low + 15*high
      /* does not overflow because A < 2*(15*Q^2/2^16 + 2^16)*n/16 < 2^25 (n<=256) */
    }
  {
    __m128i l = _mm256_extracti128_si256(A, 0);
    __m128i h = _mm256_extracti128_si256(A, 1);
    l = _mm_add_epi32(l, h);
    l = _mm_hadd_epi32(l, l);
    uint32_t z=_mm_extract_epi32(l, 0) + _mm_extract_epi32(l, 1);
    return NORMAL(z);
  }
}
#elif SIZE_GFQ == 2
static GFq main_comp_internal(GFq* a,GFq* b,const uint32_t n)
{
  __m256i A=_mm256_setzero_si256();
  for(int32_t i=n-16;i>=0;i-=16)
    {
      __builtin_prefetch(a+i-16);
      __builtin_prefetch(b+i-16);

      __m256i x=_mm256_load_si256((m256_ptr)(a+i));  /* <a0,a1,a2,a3,...,a16> */
      __m256i y=_mm256_load_si256((m256_ptr)(b+i));  /* <b0,b1,b2,b3,...,b16> */
      y=_mm256_madd_epi16(x,y);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a16*b16> */
      A=_mm256_add_epi32(A,y);
    }
  {
    __m128i l = _mm256_extracti128_si256(A, 0);
    __m128i h = _mm256_extracti128_si256(A, 1);
    l = _mm_add_epi32(l, h);
    l = _mm_hadd_epi32(l, l);
    uint32_t z=_mm_extract_epi32(l, 0) + _mm_extract_epi32(l, 1);
    return NORMAL(z);
  }
}
#else /*  SIZE_GFQ == 2 */
static GFq main_comp_internal(GFq* a,GFq* b,const uint32_t n)
{
  const __m256i izero = _mm256_setzero_si256();
  __m256i A=izero;
  uint32_t i=0;
  __m256i x=_mm256_load_si256((m256_ptr)(a+i));  /* <a0,a1,a2,a3,...,a15> */
  __m256i y=_mm256_load_si256((m256_ptr)(b+i));  /* <b0,b1,b2,b3,...,b15> */
  __m256i X=_mm256_load_si256((m256_ptr)(a+32));
  __m256i Y=_mm256_load_si256((m256_ptr)(b+32));
  {
    __m256i xh = _mm256_unpackhi_epi8(x, izero);
    __m256i yh = _mm256_unpackhi_epi8(y, izero);
    yh=_mm256_madd_epi16(xh,yh);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a7*b7> */
    A=_mm256_add_epi32(A,yh);
    __m256i xl = _mm256_unpacklo_epi8(x, izero);
    __m256i yl = _mm256_unpacklo_epi8(y, izero);
    yl=_mm256_madd_epi16(xl,yl);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a7*b7> */
    A=_mm256_add_epi32(A,yl);
  }
  for(i=32;i<n-32;i+=32)
    {
      x=X;
      y=Y;
      X=_mm256_load_si256((m256_ptr)(a+i+32));  /* <a0,a1,a2,a3,...,a15> */
      Y=_mm256_load_si256((m256_ptr)(b+i+32));  /* <b0,b1,b2,b3,...,b15> */
      {
	__m256i xh = _mm256_unpackhi_epi8(x, izero);
	__m256i yh = _mm256_unpackhi_epi8(y, izero);
	yh=_mm256_madd_epi16(xh,yh);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a7*b7> */
	A=_mm256_add_epi32(A,yh);
	__m256i xl = _mm256_unpacklo_epi8(x, izero);
	__m256i yl = _mm256_unpacklo_epi8(y, izero);
	yl=_mm256_madd_epi16(xl,yl);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a7*b7> */
	A=_mm256_add_epi32(A,yl);
      }
    }
  x=X;
  y=Y;
  {
    __m256i xh = _mm256_unpackhi_epi8(x, izero);
    __m256i yh = _mm256_unpackhi_epi8(y, izero);
    yh=_mm256_madd_epi16(xh,yh);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a7*b7> */
    A=_mm256_add_epi32(A,yh);
    __m256i xl = _mm256_unpacklo_epi8(x, izero);
    __m256i yl = _mm256_unpacklo_epi8(y, izero);
    yl=_mm256_madd_epi16(xl,yl);            /* <a0*b0+a1*b1,a2*b2+a3*b3,a4*b4+a5*b5,a6*b6+a7*b7> */
    A=_mm256_add_epi32(A,yl);
  }
  {
    __m128i l = _mm256_extracti128_si256(A, 0);
    __m128i h = _mm256_extracti128_si256(A, 1);
    l = _mm_add_epi32(l, h);
    l = _mm_hadd_epi32(l, l);
    uint32_t z=_mm_extract_epi32(l, 0) + _mm_extract_epi32(l, 1);
    return NORMAL(z);
  }
}
#endif /*  SIZE_GFQ == 2 */
